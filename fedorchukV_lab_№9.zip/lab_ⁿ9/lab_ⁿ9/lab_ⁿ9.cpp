﻿#include <iostream>
using namespace std;
class pile {
	int* mas;//массив который будет нашей кучей в этом задании
	int d;//кол-во сыновей
	int size;//размер кучи
	void swap(int i, int j) {//меняет местами ключи вершин i - j
		int tmp = mas[i];
		mas[i] = mas[j];
		mas[j] = tmp;
	}
	//при добавлении элемента переделываем кучу
	void shiftUp(int i) {//восстановление инварианта для вершины i,
						 //после уменьшения значения ключа i
		while (i > 0) {
			if (mas[i] < mas[(int)floor((i - 1) / d)]) {//округление в меньшую сторону, 
				swap(i, (int)floor((i - 1) / d));       //потому индексация с 0 начинается!
			}
			i--;
		}
	}
	//при удалении элемента переделываем кучу
	void shiftDown(int i) {//восстановление инварианта для вершины i,
						   //после уменьшения значения ключа i
		while (i * d + 1 < size - 1) {//смотрим, есть ли потомки
			/////////////////////////////
			//Минимальный сын
			int minOfHeap = mas[i * d + 1];//минимальный элемент массива
			int j = i * d + 1;//минимальный элемент
			for (int r = 2; r <= d; r++) {//просматриваем цикл, начиная со второго элемента
				if (mas[i * d + r] < minOfHeap) {//если элемент кучи меньше заданного минамального
					minOfHeap = mas[i * d + r];//то делаем его минимальным
					j = i * d + r;//
				}
			}
			/////////////////////////////
			//сам наш ShiftDown
			if (mas[i] > mas[j] && j < size) {//если элемент заданного массива больше, чем элемент массива
				swap(i, j);//то меняем их местами
			}
			i = j;
			/////////////////////////////
		}
	}
	//заполнение кучи
	void setpile(int* m) {//строим кучу
		for (int i = 0; i < size; i++) {
			mas[i] = m[i];
			shiftUp(i);
		}
	}
public:
	pile(int* mas, int d, int s) {
		this->d = d;
		size = s;
		this->mas = new int[size];
		setpile(mas);
	}
	~pile() {
	};
	//вывод (кривой)
	//1 2 3 4 5 6 7 8 9 10 11 12 13
	void print(const string& str, int n, bool temp)//Вывод
	{//temp проверка нужно ли рисовать сыновей или идем на ряд дальше
		if (n < size)
		{
			cout << str;        cout << "|_:" << mas[n] << std::endl;
			for (int i = 1; i < d; i++) {
				if (temp)      print(str + "|   ", d * n + i, true);
				else           print(str + "    ", d * n + i, true);
			}
			if (temp)      print(str + "|   ", d * n + d, false);
			else           print(str + "    ", d * n + d, false);
		}
	}
	//для нахождения глубины дерева
	int Pow(int d, int m) {
		int glubina = 0;
		for (int i = 0; i < m; i++) {
			if (pow(d, i) <= m)
				glubina++;
		}
		return glubina;
	}
	//вставка произвольного нового элемента в кучу
	void insert(int element) {
		mas[size] = element;
		shiftUp(size);//функция восстановления инварианта
		size++;
	}
	//удалить элемент с минимальным ключом из кучи
	void delete_min() {
		swap(0, size - 1);
		size--;
		shiftDown(0);
	}
	//возврат минимального
	int getMin() {
		return mas[0];
	}

};
int main() {
	int sizeOfpile;//размер кучи
	int insertElement;//элемент для вставки
	setlocale(LC_ALL, "ru");
	cout << "Введите размер кучи:" << endl;
	cin >> sizeOfpile;
	cout << "Введите кучу:" << endl;
	int* mas = new int[sizeOfpile];
	for (int i = 0; i < sizeOfpile; i++) {
		cin >> mas[i];
	}
	//создание объекта-кучи на основе класса(массив вершин, кол-во сыновей макс, размер)
	pile heap(mas, 3, sizeOfpile);//d-3 куча
	heap.print("", 0, false);//в начале не будет ничего-str, а вот потом будем просматривать ветки и сыновей
	//вывод с нуля начинаем и пока что мы имеем только одного сына - вершину
	//heap.printA();//вывод 
	heap.delete_min();//удаление минимального
	cout << endl;
	heap.print("", 0, false);//вывод 
	cout << endl;
	cout << "Введите элемент, который хотите вставить:" << endl;
	cin >> insertElement;
	heap.insert(insertElement);//вставка
	cout << endl;
	heap.print("", 0, false);//вывод 
	cout << endl; cout << endl;
	//heap.print();
	return 0;
}
