﻿#include <iostream>
using namespace std;
int i, j, d;
//--СОРТИРОВКА ВЫБОРОМ--//
void selection_sort(int a[], int size) {
	int i, min, j;
	for (i = 0; i < size - 1; i++) {
		min = i;
		for (j = i + 1; j < size; j++) {
			if (a[j] < a[min]) { min = j; }
		}
		swap(a[min], a[i]);
	}
}
//--СОРТИРОВКА ВСТАВКАМИ--//
void ins_sort(int a[], int size) {
	int i, j, key;
	for (i = 1; i < size; i++) {
		key = a[i];
		j = i - 1;
		while (j >= 0 && a[j] > key) {
			a[j + 1] = a[j];
			j = j - 1;
			a[j + 1] = key;
		}
	}
}
//--СОРТИРОВКА ПУЗЫРЬКОМ--//
void bubble_sort(int a[], int size) {
	int i, j;
	for (i = 0; i < size; i++) {
		for (j = 0; j < size - 1; j++) {
			if (a[j + 1] < a[j])swap(a[j + 1], a[j]);
		}
	}
}
//--СОРТИРОВКА БЫСТРАЯ--//
void quick_sort(int* a, int first, int last) {
	int mid;
	int f = first, l = last;
	mid = a[(f + l) / 2];
	do
	{
		while (a[f] < mid) f++;
		while (a[l] > mid) l--;
		if (f <= l)
		{
			swap(a[f], a[l]);
			f++;
			l--;
		}
	} while (f < l);
	if (first < l) quick_sort(a, first, l);
	if (f < last) quick_sort(a, f, last);
}
void Shell(int A[], int n, int count) //сортировка Шелла
{
	d = n;
	d = d / 2;
	while (d > 0)
	{
		for (i = 0; i < n - d; i++)
		{
			j = i;
			while (j >= 0 && A[j] > A[j + d])
			{
				count = A[j];
				A[j] = A[j + d];
				A[j + d] = count;
				j--;
			}
		}
		d = d / 2;
	}
}
//главная функция
int main()
{
	int  n, count=0;
	int number;
	
	setlocale(LC_ALL, "Rus");
	cout << "Размер массива > "; cin >> n;
	int first = 0,
		last = n - 1;
	int* A = new int[n]; //объявление динамического массива
	for (i = 0; i < n; i++) //ввод массива
	{
		cout << i + 1 << " элемент > "; cin >> A[i];
	}
	cout << "Selection sort = 1" << endl;
	cout << "Insertion sort = 2" << endl;
	cout << "Bubble sort = 3" << endl;
	cout << "Quick sort = 4" << endl;
	cout << "Merge sort = 5" << endl;
	cout << "Enter number" << endl;
	cin >> number;
	switch (number) {
	case 1:selection_sort(A, n); break;
	case 2:ins_sort(A, n); break;
	case 3:bubble_sort(A, n);; break;
	case 4:quick_sort(A, first, last); break;
	case 5:Shell(A, n, count); break;
	default:cout << "nothing"; break;
	}
	cout << "отсортированный массив" << endl;
	for (int i = 0; i < n; i++)
		cout << A[i] << " ";
	
	return 0;
}